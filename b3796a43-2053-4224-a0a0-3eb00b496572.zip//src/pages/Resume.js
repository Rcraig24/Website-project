import ResumeItem from "../components/ResumeItem";

export default function CybersecuritySafety() {
  return <>Cybersecuity Safety</>;
}
